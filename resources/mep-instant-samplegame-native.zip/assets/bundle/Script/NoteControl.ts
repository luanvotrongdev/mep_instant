import StateControl, { GameState } from './StateControl'

const { ccclass, property } = cc._decorator

export interface NoteControlOptions {
  x: number
  y: number
  color: cc.Color
  perfect: number
  bottom: number
  velocity: number
  onOutOfScreen: () => void
  onTapNote: () => void
}

@ccclass
export default class NoteControl extends cc.Component {
  stateControl: StateControl = null
  solidNode: cc.Node = null
  strokeNode: cc.Node = null
  options: NoteControlOptions = null

  init(options: NoteControlOptions) {
    this.node.x = options.x
    this.node.y = options.y
    this.solidNode.color = options.color
    this.strokeNode.color = options.color
    this.options = options
    this.strokeNode.active = false
    this.strokeNode.scale = 1
    this.node.opacity = 255;
  }

  onLoad() {
    this.stateControl = cc.Canvas.instance.node.getComponent('StateControl')
    this.solidNode = this.node.getChildByName('solid')
    this.strokeNode = this.node.getChildByName('stroke')
  }

  start() {
    this.node.on(cc.Node.EventType.TOUCH_START, this.processOnTapNote, this);
  }

  processOnTapNote() {
    if (this.options && this.options.onTapNote) {
      this.options.onTapNote();
      this.options.onTapNote = null;
    }
  }

  update(dt: number) {
    if (this.stateControl.state !== GameState.Playing) return

    const distance = this.options.velocity * dt
    this.node.y -= distance

    // if (AUTO_PLAY && Math.abs(this.node.y - this.options.perfect) <= 0.2 * this.node.height) {
    //   this.processOnTapNote();
    // }

    // if (this.node.y < this.options.perfect) {w
    //   this.solidNode.color = cc.Color.WHITE
    //   this.strokeNode.color = cc.Color.WHITE
    //   this.strokeNode.active = true
    //   this.strokeNode.scale = 1.5
    // }

    if (this.node.y + this.node.height / 2 < this.options.bottom) {
      if (this.options.onOutOfScreen) {
        this.options.onOutOfScreen();
        this.options.onTapNote = null;
        this.options = null;
      }
    }
  }
}
