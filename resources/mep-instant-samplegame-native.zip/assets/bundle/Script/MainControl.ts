import NoteControl from './NoteControl'
import StateControl, { GameState } from './StateControl'

declare var MEPInstant: any;

const { ccclass, property } = cc._decorator

@ccclass
export default class MainControl extends cc.Component {
  @property(cc.Prefab)
  notePrefab: cc.Prefab = null

  @property(cc.Button)
  startBtn: cc.Button = null

  @property(cc.Button)
  pauseBtn: cc.Button = null

  @property(cc.Node)
  perfectLineNode: cc.Node = null

  @property(cc.Label)
  scoreLabel: cc.Label = null;
  @property(cc.Label)
  comboLabel: cc.Label = null;
  @property(cc.Label)
  songLabel: cc.Label = null;
  @property(cc.Node)
  loading: cc.Node = null;
  @property(cc.Node)
  deadline: cc.Node = null;

  stateControl: StateControl = null
  notes: MEPInstant.Note[] = null
  activeNotes: any = {}
  noteParentNode: cc.Node = null
  notePool: cc.NodePool = new cc.NodePool()

  time: number = 0
  musicDuration: number = 0
  noteVelocity: number = 0

  musicPlayer: any = null;

  score: number = 0;
  catchedNotes: number = 0;
  totalNotes: number = 0;
  reviveCount: number = 0;
  gameData: MEPInstant.GameData = null;

  static readonly poolSize: number = 40;
  static readonly TIME_TO_PERFECT: number = 3; // 4s, time from top to perfect line.
  static readonly SCORE_DICT: Object = {
    'PERFECT': 5,
    'GREAT': 2,
    'COOL': 1,
    'MISS': 0
  };

  // LIFE-CYCLE CALLBACKS:

  onLoad() {
    this.startBtn.node.on(
      cc.Node.EventType.TOUCH_END,
      this.onStartTouched,
      this
    )
    this.pauseBtn.node.on(
      cc.Node.EventType.TOUCH_END,
      this.onPauseTouched,
      this
    )

    this.startBtn.node.active = false
    this.pauseBtn.node.active = false

    this.initNotesPool(MainControl.poolSize)
    this.stateControl = cc.Canvas.instance.node.getComponent('StateControl')
    this.noteParentNode = this.node.getChildByName('noteParent')

    const perfectDistance =
      cc.Canvas.instance.node.height / 2 - this.perfectLineNode.y
    this.noteVelocity = perfectDistance / MainControl.TIME_TO_PERFECT

    MEPInstant.initializeAsync().then(() => {

      //get game data
      MEPInstant.startGameAsync().then(gameData => this.setupGame(gameData));

      //background
      MEPInstant.onPause(() => {
        console.log('Pause Game');
        this.doPause();
      })

      //foreground
      MEPInstant.onResume(() => {
        console.log('Resume Game');
        this.doResume();
      })

    })
  }

  setupGame(gameData: MEPInstant.GameData) {
    const self = this
    self.gameData = gameData
    self.songLabel.string = gameData.song.title + '\n' + gameData.song.artist;

    Promise.all([
      self.initMusicPlayer(gameData.song.mp3Url),
      MEPInstant.getNotesAsync(gameData.song.levelUrl)

    ]).then((values) => {
      self.processNotes(values[1].notes);
      self.totalNotes = self.notes.length
      self.musicPlayer.getDuration().then(duration => self.musicDuration = duration)
      self.startBtn.node.active = true

      //process multiplayer
      if (MEPInstant.isPvP()) {
        MEPInstant.sendGameReady()

        MEPInstant.onStartCountDown(() => {
          //we need hide loading or something ui
          cc.tween(this.loading)
            .to(1, { opacity: 0 })
            .call(() => { this.loading.stopAllActions() })
            .start()
        })

        //transition to start game
        MEPInstant.onStartPvP(() => {
          self.stateControl.state = GameState.Ready
          self.onStartTouched();
        })

        //Finish match, you win
        MEPInstant.onGameResult(() => this.doEndGame())

        //force endgame
        MEPInstant.onDisconnect(() => this.doEndGame())
      }
      else { //single
        self.stateControl.state = GameState.Ready
        this.loading.active = false;
      }

    })
  }

  processNotes(notes: MEPInstant.Note[]) {
    let noteFilters = notes.filter(note => note.time > 0.5);
    this.notes = [notes[0]]
    for(let i = 1, size = noteFilters.length; i < size; ++i) {
      let noteData = noteFilters[i]
      let deltaTime = noteData.time - notes[this.notes.length - 1].time;
      if (deltaTime >= 0.3) {
        this.notes.push(noteData);
      }
    }
  }

  setScore(status: string) {
    this.score += MainControl.SCORE_DICT[status];
    this.scoreLabel.string = this.score.toString();
    this.comboLabel.string = status;

    //update score with pvp
    if (MEPInstant.isPvP()) {
      MEPInstant.sendScoreRequest(this.score);
    }
  }

  update(dt) {
    if (this.stateControl.state !== GameState.Playing) return

    this.time += dt

    if (this.time > this.musicDuration) {
      this.doEndGame();
      return
    }

    const newNotes = this.notes.filter(it => {
      const notActive = !this.activeNotes[it.time]
      return (
        notActive &&
        it.time >= this.time &&
        it.time < this.time + MainControl.TIME_TO_PERFECT + 1
      )
    })

    if (newNotes.length > 0) {
      newNotes.forEach(note => {
        this.activeNotes[note.time] = note
        this.spawnNode(note)
      })
    }
  }

  onStartTouched() {
    this.musicPlayer.getCurrentTime().then(currentTime => {
      this.time = currentTime;
      this.musicPlayer.play();
    })
    this.stateControl.state = GameState.Playing
    this.startBtn.node.active = false
    this.pauseBtn.node.active = true
  }

  onPauseTouched() {
    this.doPause();
  }

  doPause() {
    this.musicPlayer.pause()
    this.stateControl.state = GameState.Pause;
    this.startBtn.node.active = true
    this.pauseBtn.node.active = false

    //force end game with pvp mode
    if (MEPInstant.isPvP()) {
      this.doEndGame()
    }
  }

  doResume() {
    this.musicPlayer.resume()
    this.stateControl.state = GameState.Playing;
  }

  doEndGame() {
    this.stateControl.state = GameState.GameOver

    this.musicPlayer.stop();
    let percent = this.catchedNotes / this.totalNotes;
    let loop = Math.floor(percent + 0.5);
    MEPInstant.endGame({
      score: this.score,
      star: 0,
      crown: 0,
      percent: percent,
      loop: loop,
      notes: this.catchedNotes,
      revise: this.reviveCount,
    })
  }

  doDeath() {
    this.stateControl.state = GameState.GameOver
    this.doPause();

    //pvp just send endGame
    if (MEPInstant.isPvP()) {
      this.doEndGame();
    }
    else {
      MEPInstant.showReviveConfirmation(
        () => {
          this.doResume();
        },
        () => {
          this.doEndGame();
        })
    }
  }

  private initNotesPool(size: number) {
    this.notePool = new cc.NodePool()
    for (let i = 0; i < size; ++i) {
      let node = cc.instantiate(this.notePrefab) // create node instance
      this.notePool.put(node) // populate your pool with put method
    }
  }

  private initMusicPlayer(mp3Url: string): Promise<any> {
    const self = this;
    return new Promise((resolve, _reject) => {
      self.musicPlayer = MEPInstant.createMusicPlayer({
        src: mp3Url,
        onLoad: () => {
          resolve(self.musicPlayer)
        }
      });
    })
  }

  private spawnNode(note: MEPInstant.Note) {
    let noteNode: cc.Node = null
    if (this.notePool.size() > 0) {
      // use size method to check if there're nodes available in the pool
      noteNode = this.notePool.get()
    } else {
      // if not enough node in the pool, we call cc.instantiate to create node
      noteNode = cc.instantiate(this.notePrefab)
    }
    // this.noteParentNode.addChild(noteNode) // add new note node to the node tree
    noteNode.parent = this.noteParentNode // add new note node to the node tree
    const noteControl: NoteControl = noteNode.getComponent(NoteControl)
    const time = note.time - this.time
    noteControl.init({
      x: this.getNoteX(note),
      y: this.perfectLineNode.y + time * this.noteVelocity,
      perfect: this.perfectLineNode.y,
      bottom: this.deadline.y,
      velocity: this.noteVelocity,
      color: this.getNoteColor(note),
      onOutOfScreen: () => {
        this.notePool.put(noteNode)
      },
      onTapNote: () => {
        //check tap perfect
        {
          let diff = Math.abs(noteNode.position.y - this.perfectLineNode.y);
          let status = 'MISS';
          if (diff <= noteNode.width * 0.2) {
            status = 'PERFECT';
            this.catchedNotes += 1;
          } else if (diff <= noteNode.width * 0.6) {
            status = 'GREAT';
            this.catchedNotes += 1;
          } else if (diff <= noteNode.width) {
            this.catchedNotes += 1;
          } else {
            this.doDeath();
          }
          this.setScore(status);
          noteNode.opacity = 128;
        }

        //show label status
        {
          let wPos = noteNode.parent.convertToWorldSpaceAR(noteNode.getPosition());
          const localPos = this.comboLabel.node.parent.convertToNodeSpaceAR(wPos);
          cc.tween(this.comboLabel.node)
            .to(0.1, { opacity: 255 }, { easing: 'expoIn' })
            .to(0.1, { opacity: 0 }, { easing: 'expoOut' })
            .start();
          this.comboLabel.node.setPosition(localPos);
        }

      }
    })
  }

  private getNoteX(note: MEPInstant.Note): number {
    let line
    switch (note.name.toUpperCase()) {
      case 'C4':
      case 'C5':
        line = 1
        break

      case 'C#4':
      case 'C#5':
        line = 2
        break

      case 'D4':
      case 'D5':
        line = 3
        break

      case 'D#4':
      case 'D#5':
        line = 4
        break

      case 'E4':
      case 'E5':
        line = 5
        break

      default:
        line = 1
    }

    return (
      (cc.Canvas.instance.node.width / 6) * line -
      cc.Canvas.instance.node.width / 2
    )
  }

  private getNoteColor(note: MEPInstant.Note): cc.Color {
    switch (note.name.toUpperCase()) {
      case 'C4':
      case 'C5':
        return cc.Color.RED

      case 'C#4':
      case 'C#5':
        return cc.Color.GREEN

      case 'D4':
      case 'D5':
        return cc.Color.ORANGE

      case 'D#4':
      case 'D#5':
        return cc.Color.CYAN

      case 'E4':
      case 'E5':
        return cc.Color.YELLOW

      default:
        return cc.Color.CYAN
    }
  }
}
