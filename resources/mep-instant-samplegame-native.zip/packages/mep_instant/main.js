var path = require('path');
var fs = require('fs');
var mep_setting = require('./data/masterdata');

function onBuildStart(options, callback) {
  callback();
}

function onBuildFinished(options, callback) {
  var mainBundle = "";
  let bundleSize = options.bundles.length;
  let settings = options.settings;
  for (var i = 0; i < bundleSize; ++i) {
    if (options.bundles[i].scenes.length > 0) {
      mainBundle = path.join(options.bundles[i].dest, 'settings.js');
      mep_setting.game_id = options.bundles[i].name;
      break;
    }
  }
  
  mep_setting.game_bundle_dictionary = {};
  for (var i = 0; i < bundleSize; ++i) {
    mep_setting.game_bundle_dictionary[options.bundles[i].name] = options.bundles[i].name;
  }

  settings.remoteBundles = false;
  settings.jsList = [];
  var jsonStr = 'window._CCSettings=' + JSON.stringify(settings) + ';\n';
  jsonStr += 'window._MEPSettings=' + JSON.stringify(
    {
      mep_instant_ver: mep_setting.mep_instant_ver,
      game_id: mep_setting.game_id,
      game_verison: mep_setting.game_version,
      game_bundle_dictionary: mep_setting.game_bundle_dictionary
    }
  );
  fs.writeFileSync(mainBundle, jsonStr);

  Editor.log(jsonStr);
  callback();
}

module.exports = {
  messages: {
    'doOpenPanel'() {
      Editor.Panel.open('mep_instant');
    },
    'onClickConfirmGameVersion'(e, gameVersion) {
      mep_setting.game_version = gameVersion;
    },
    'onClickConfirmMEPInstantVersion'(e, mepInstantVersion) {
      mep_setting.mep_instant_ver = mepInstantVersion;
    }
  },

  load() {
    Editor.Builder.on('build-start', onBuildStart);
    Editor.Builder.on('build-finished', onBuildFinished);
  },

  unload() {
    Editor.Builder.removeListener('build-start', onBuildStart);
    Editor.Builder.removeListener('build-finished', onBuildFinished);
  }


};