mep_setting = {}

mep_setting.game_version = -1;
mep_setting.mep_instant_ver = '2.3.0-alpha8';
mep_setting.game_id = '';
mep_setting.game_bundle_dictionary = {};

module.exports = {
  mep_setting
}